package com.example.event_booking_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Event_RecyclerViewAdapter(private val eventList: MutableList<EventItem>) :
    RecyclerView.Adapter<Event_RecyclerViewAdapter.EventViewHolder>() {

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val eventImage: ImageView = itemView.findViewById(R.id.event_image)
        val eventName: TextView = itemView.findViewById(R.id.event_name)
        val eventDate: TextView = itemView.findViewById(R.id.event_date)
        val eventDescription: TextView = itemView.findViewById(R.id.event_description)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_view_event_row,
            parent,
            false
        )
        return EventViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val currentItem = eventList[position]

        holder.eventImage.setImageDrawable(currentItem.eventImageResource)
        holder.eventName.text = currentItem.eventName
        holder.eventDate.text = currentItem.eventDate
        holder.eventDescription.text = currentItem.eventDescription
    }

    override fun getItemCount() = eventList.size
}
