package com.example.event_booking_app

import android.graphics.drawable.Drawable

data class EventItem(
    var eventImageResource: Drawable?,
    var eventName: String,
    var eventDate: String,
    var eventDescription: String
)

