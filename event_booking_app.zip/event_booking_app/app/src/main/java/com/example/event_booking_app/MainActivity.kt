package com.example.event_booking_app

import android.content.Context
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File


class MainActivity : AppCompatActivity() {

    // I suppose the list should be mutable considering
    // that events might change during runtime due to updates.
    private var eventList: MutableList<EventItem> = mutableListOf() //empty mutable list
    // An eventImageList of icons corresponding to our events.
    private var eventImageList = mutableListOf<Drawable>()
    //var eventImageIds =

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        eventImageList = loadVectorImages(context = this)
        eventList = setEventList(eventImageList,eventList)

        //RecyclerView recyclerViewEvents = findViewById(R.id.recyclerViewEvents)
        val recyclerViewEvents = findViewById<RecyclerView>(R.id.recyclerViewEvents)
        recyclerViewEvents.layoutManager = LinearLayoutManager(this)

        val adapter = Event_RecyclerViewAdapter(eventList)
        recyclerViewEvents.adapter = adapter



    }

    fun loadVectorImages(context: Context): MutableList<Drawable>{
        // Get number of images
        val eventImageIds = mutableListOf<Int>()
        val fields = R.drawable::class.java.fields
        val numImages = fields.size

        //Get imageId from its name and add it to eventImageIds list
        Log.d("myTag", "This is my message"+numImages);
        for (i in 1..numImages-2) {
            val eventImageId = context.resources.getIdentifier("ic_$i", "drawable", context.packageName)
            eventImageIds.add(eventImageId)
        }
        //Finally create the eventImageList
        val drawableList = mutableListOf<Drawable>()
        for (id in eventImageIds) {
            val drawable = context.resources.getDrawable(id, context.theme)

            drawableList.add(drawable)
        }

        return drawableList
    }

    fun setEventList(list1: MutableList<Drawable>, list2: MutableList<EventItem>): MutableList<EventItem> {

        val eventNames =  resources.getStringArray(R.array.event_names_txt)
        val eventDates = resources.getStringArray(R.array.event_dates_txt)
        val eventDescriptions = resources.getStringArray(R.array.event_descriptions_txt)
        //list2.clear()

        // Initialize the list with the same number of elements as the eventNames array
        list2.addAll(List(eventNames.size) { EventItem(null, "", "", "") })

        for (i in 0 until eventNames.size) {
            list2[i].eventName = eventNames[i]
            list2[i].eventDate = eventDates[i]
            list2[i].eventDescription = eventDescriptions[i]
            list2[i].eventImageResource = list1[i]
        }
        return list2
    }


}